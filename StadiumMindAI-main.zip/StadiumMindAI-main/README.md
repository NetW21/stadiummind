# 🏟️ StadiumMind AI

![React](https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6?logo=typescript&logoColor=white)
![Firebase](https://img.shields.io/badge/Firebase-Enabled-FFCA28?logo=firebase&logoColor=black)
![Google Gemini](https://img.shields.io/badge/Google-Gemini_2.5-4285F4?logo=google&logoColor=white)
![Cloud Run](https://img.shields.io/badge/Google-Cloud_Run-4285F4?logo=googlecloud&logoColor=white)
![Vite](https://img.shields.io/badge/Vite-Latest-646CFF?logo=vite&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green)

> **An Autonomous GenAI-powered Smart Stadium Operating System built for the Google for Developers – Virtual Prompt Wars 2026 challenge, leveraging Google Gemini, Firebase, Cloud Run, and Multi-Agent AI to enhance FIFA World Cup 2026 stadium operations.**

---

# 🌐 Live Demo

**🚀 Application**

https://stadiummind-ai-11227005249.asia-southeast1.run.app

<img width="1570" height="867" alt="image" src="https://github.com/user-attachments/assets/87c16280-05cc-4882-b62d-d70fd600ff30" />


---

# 💻 GitHub Repository

https://github.com/instathoughts7-ai/StadiumMindAI

---

# 🏆 Google for Developers – Virtual Prompt Wars 2026

## Challenge

### Smart Stadiums & Tournament Operations

Build a GenAI-enabled solution that enhances stadium operations and improves the overall tournament experience for:

- ⚽ Fans
- 🏟 Stadium Operators
- 👮 Security Teams
- 🚑 Emergency Responders
- 🦺 Volunteers
- 🚍 Transportation Teams
- ♿ Accessibility Coordinators

during the **FIFA World Cup 2026**.

---

# ❗ Problem Statement

Managing a FIFA World Cup stadium with more than **80,000 spectators** requires thousands of operational decisions every minute.

Current stadium management systems are largely reactive and disconnected, making it difficult to:

- Predict crowd congestion
- Reduce entry gate waiting times
- Coordinate volunteers efficiently
- Respond quickly to emergencies
- Optimize transportation logistics
- Assist visitors with accessibility needs
- Provide multilingual assistance
- Deliver actionable operational intelligence

These challenges impact fan experience, operational efficiency, accessibility, and safety.

---

# 💡 Solution Overview

**StadiumMind AI** is an autonomous GenAI-powered Smart Stadium Operating System that transforms stadium management from reactive monitoring into proactive operational intelligence.

Instead of simply displaying dashboards, StadiumMind AI continuously analyzes operational data, predicts emerging situations, and delivers AI-powered recommendations to help stadium teams make faster and better decisions.

---

# ✨ Key Features

## 🚦 Crowd Intelligence

- Live Crowd Density Monitoring
- AI Crowd Heatmaps
- Queue Prediction
- Gate Optimization
- Congestion Alerts

---

## 🗺 AI Navigation

- Intelligent Indoor Navigation
- Least Crowded Route Suggestions
- Accessible Route Planning
- Emergency Evacuation Guidance

---

## 🚨 Emergency Response Center

- Incident Reporting
- AI Response Recommendations
- Incident Prioritization
- Emergency Coordination
- Evacuation Planning

---

## 🚍 Transportation Intelligence

- Shuttle Optimization
- Parking Recommendations
- Public Transport Guidance
- Traffic Flow Monitoring

---

## 🦺 Volunteer Operations

- Volunteer Assignment
- Zone Allocation
- Live Task Coordination
- AI Task Prioritization

---

## ♿ Accessibility Assistant

- High Contrast Mode
- Dynamic Font Scaling
- Accessible Route Guidance
- Voice Assistance Ready

---

## 🌍 Multilingual Assistant

Provides multilingual communication support for international fans and operational staff.

---

## 📊 Operations Command Center

Monitor real-time:

- Crowd Status
- Active Incidents
- Emergency Alerts
- Transportation Operations
- Volunteer Deployment
- Stadium Health
- AI Operational Insights

---

# 🤖 Multi-Agent AI Architecture

StadiumMind AI operates using specialized autonomous AI agents working together.

### 🧠 Operations Commander

Coordinates all operational agents and generates strategic recommendations.

### 👥 Crowd Intelligence Agent

Predicts crowd movement and detects congestion.

### 🗺 Navigation Agent

Generates intelligent navigation and accessible routes.

### 🚨 Emergency Response Agent

Assists emergency teams with response recommendations.

### 🚍 Transportation Agent

Optimizes transportation and shuttle movement.

### ♿ Accessibility Agent

Provides accessibility guidance and inclusive navigation.

---

# 🏗 System Architecture

```text
                          Users
                             │
 ┌────────────┬──────────────┬─────────────┬──────────────┐
 │            │              │             │              │
Fans    Volunteers    Organizers    Operators    Security
 │            │              │             │              │
 └────────────┴──────────────┴─────────────┴──────────────┘
                             │
                             ▼
                 React + TypeScript Frontend
                             │
                             ▼
                    Express Backend API
                             │
                             ▼
                  Google Gemini 2.5 Flash
                             │
          ┌────────────┬─────────────┬─────────────┐
          │            │             │             │
 Crowd AI   Navigation   Emergency   Accessibility
          │            │             │             │
          └────────────┴─────────────┴─────────────┘
                             │
                             ▼
                  Firebase Firestore
                             │
                             ▼
                   Google Cloud Run
```

---

# ☁ Google Technologies Used

- Google AI Studio
- Google Gemini 2.5 Flash
- Firebase Authentication
- Cloud Firestore
- Google Cloud Run
- Google Maps Platform *(where applicable)*
- Google Identity Services *(future enhancement)*

---

# 🛠 Technology Stack

### Frontend

- React
- TypeScript
- Vite
- Tailwind CSS

### Backend

- Node.js
- Express.js

### AI

- Google Gemini 2.5 Flash
- Multi-Agent AI

### Database

- Firebase Firestore

### Deployment

- Google Cloud Run

### Testing

- Vitest

---

# 🔒 Security

- Server-side Gemini API integration
- Secure Environment Variables
- Prompt Injection Mitigation
- Input Validation
- REST API Security
- Firestore-ready Security Architecture
- No Client-side API Keys

---

# ⚡ Performance

- Lightweight SVG Visualizations
- Tree Shaking
- ESBuild Optimization
- Optimized Polling
- Cloud Run Optimized Deployment
- Modular Architecture
- Fast Rendering

---

# ♿ Accessibility

Designed following **WCAG 2.2 AA** principles.

Features include:

- High Contrast Mode
- Keyboard Navigation
- Dynamic Font Scaling
- Screen Reader Support
- Semantic HTML
- Accessible Route Planning

---

# 🧪 Testing

Current automated validation includes:

- API Testing
- Component Testing
- Integration Testing
- AI Agent Contract Testing
- Error Handling Tests
- Fallback Logic Validation
- Performance Validation
- Accessibility Validation

---

# 📁 Project Structure

```text
src/
├── agents/
├── components/
├── hooks/
├── services/
├── lib/
├── context/
├── types/
├── utils/

server/

tests/

public/
```

---

# 🚀 Getting Started

## Clone Repository

```bash
git clone https://github.com/instathoughts7-ai/StadiumMindAI.git
```

## Install Dependencies

```bash
npm install
```

## Configure Environment Variables

Create a `.env` file.

```env
GEMINI_API_KEY=YOUR_GEMINI_API_KEY
```

## Run Development Server

```bash
npm run dev
```

## Build for Production

```bash
npm run build
```

---

# ⚽ Example Use Case

### Match Day at Estadio Azteca

A sold-out FIFA World Cup match attracts more than **80,000 spectators**.

### Step 1

StadiumMind AI detects increasing congestion at Gate A.

### Step 2

The Crowd Intelligence Agent predicts queue growth before delays occur.

### Step 3

The Navigation Agent recommends alternate entry gates.

### Step 4

Volunteers receive updated assignments.

### Step 5

Transportation schedules are adjusted.

### Step 6

Accessible routes are generated for visitors requiring assistance.

### Step 7

Emergency responders receive AI-generated action recommendations.

### Step 8

Tournament organizers monitor the entire stadium through a unified Operations Command Center.

Result:

- Reduced congestion
- Faster stadium entry
- Better accessibility
- Improved operational efficiency
- Enhanced fan experience

---

# 📊 Evaluation Alignment

| Evaluation Criteria | Coverage |
|----------------------|----------|
| ✅ Problem Solving & Impact | Intelligent stadium operations |
| ✅ Agentic Depth | Autonomous Multi-Agent AI |
| ✅ Innovation & Creativity | Predictive operational intelligence |
| ✅ Google Technologies | Gemini, Firebase, Cloud Run |
| ✅ Product Experience | Responsive Operations Command Center |
| ✅ Technical Implementation | Full-stack TypeScript Architecture |
| ✅ Completeness & Usability | Working End-to-End Platform |

---

# 🚀 Future Enhancements

- Indoor Google Maps Navigation
- Real-Time Firestore Synchronization
- AI Predictive Crowd Analytics
- AI Incident Forecasting
- Sustainability Dashboard
- Carbon Footprint Analytics
- Voice-Based AI Assistant
- Wear OS Companion

---

# 👨‍💻 Author

**Mahesh V. Waghmode**

**GitHub**

https://github.com/instathoughts7-ai

**LinkedIn**

https://www.linkedin.com/in/maheshwaghmode/

---

# ⭐ Support

If you found this project useful, consider giving it a **⭐ Star** on GitHub.

---

# 📄 License

MIT License

This project was developed for the **Google for Developers – Virtual Prompt Wars 2026** challenge to demonstrate how Generative AI can enhance smart stadium operations and tournament management for the FIFA World Cup 2026.
